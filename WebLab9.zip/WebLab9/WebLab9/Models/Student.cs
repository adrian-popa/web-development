using System;

namespace WebLab9.Models
{
    public class Student
    {
        public int Id { get; set; }

        public string Username { get; set; }

        public int GroupId { get; set; }

        public float Grade { get; set; }
    }
}
