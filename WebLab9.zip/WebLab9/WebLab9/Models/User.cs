using System;

namespace WebLab9.Models
{
    public class User
    {
        public string Username { get; set; }

        public string Type { get; set; }
    }
}
